"""
BrapiKafkaProducer — publica preços reais da BRAPI no Kafka.

Fluxo por ciclo:
  1. Busca cotações em batch (até 10 tickers por request BRAPI)
  2. Monta MarketEvent(PRICE_UPDATE) para cada ticker
  3. Publica no tópico market-events via KafkaMarketEventProducer
  4. Dorme interval_seconds + jitter aleatório (0–20% do intervalo)
  5. Repete

Design decisions:

  Batch fetch:
    BRAPI aceita /quote/PETR4,VALE3,ITUB4 em um único request.
    Reduz consideravelmente o número de chamadas para o plano free.
    Lote máximo de 10 tickers para não estourar URL limit.

  Jitter:
    Intervalo = base ± 20% aleatório. Evita thundering herd em caso
    de múltiplas instâncias e também naturaliza o padrão de acesso à API.

  Rate limit guard:
    Rastreia última chamada por ticker. Se BRAPI retornar 429,
    recua com backoff exponencial (1s → 2s → 4s → 8s, cap 60s).

  Producer singleton:
    KafkaMarketEventProducer é criado no start() e reutilizado pelo
    loop inteiro. Não abre/fecha conexão por ciclo.

  Graceful shutdown:
    asyncio.Event para sinalizar parada. O loop verifica a cada ciclo
    antes de dormir e ao acordar.

  Estado observável:
    ProducerStats dataclass com métricas do último ciclo — exposto via
    endpoint GET /producer/status sem custo de instrumentação externa.
"""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import structlog

from finanalytics_ai.config import get_settings
from finanalytics_ai.domain.entities.event import EventType, MarketEvent
from finanalytics_ai.exceptions import MarketDataUnavailableError, TransientError

logger = structlog.get_logger(__name__)

_BATCH_SIZE = 10          # max tickers por request BRAPI
_BACKOFF_CAP = 60.0       # backoff máximo em segundos


@dataclass
class ProducerStats:
    """Estado atual do producer — exposto via /producer/status."""
    running:           bool     = False
    started_at:        str      = ""
    tickers:           list[str]= field(default_factory=list)
    poll_interval:     float    = 60.0
    cycles_total:      int      = 0
    cycles_ok:         int      = 0
    cycles_error:      int      = 0
    events_published:  int      = 0
    last_cycle_at:     str      = ""
    last_cycle_ms:     float    = 0.0
    last_error:        str      = ""
    backoff_until:     str      = ""


class BrapiKafkaProducer:
    """
    Producer que busca preços na BRAPI e publica no Kafka.
    Deve ser usado como singleton no lifespan da app.
    """

    def __init__(self) -> None:
        self._settings    = get_settings()
        self._stop_event  = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._stats       = ProducerStats()
        self._backoff: float = 0.0   # segundos de backoff atual após 429

    @property
    def stats(self) -> ProducerStats:
        return self._stats

    @property
    def is_running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def start(self) -> None:
        """Inicia o loop de polling em background."""
        if self.is_running:
            logger.warning("producer.already_running")
            return

        self._stop_event.clear()
        tickers = [t.strip().upper() for t in self._settings.producer_tickers.split(",") if t.strip()]
        self._stats = ProducerStats(
            running        = True,
            started_at     = datetime.utcnow().isoformat(),
            tickers        = tickers,
            poll_interval  = self._settings.producer_poll_interval_seconds,
        )
        self._task = asyncio.create_task(self._run_loop(tickers))
        logger.info("producer.started", tickers=tickers, interval=self._stats.poll_interval)

    async def stop(self) -> None:
        """Para o loop gracefully."""
        self._stop_event.set()
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                self._task.cancel()
        self._stats.running = False
        logger.info("producer.stopped")

    async def run_once(self, tickers: list[str]) -> int:
        """
        Executa um único ciclo de fetch+publish.
        Retorna número de eventos publicados.
        Útil para testes e disparo manual via API.
        """
        return await self._fetch_and_publish(tickers)

    # ── Internals ─────────────────────────────────────────────────────────────

    async def _run_loop(self, tickers: list[str]) -> None:
        """Loop principal — roda até _stop_event ser setado."""
        from finanalytics_ai.infrastructure.queue.kafka_adapter import KafkaMarketEventProducer

        kafka_producer = KafkaMarketEventProducer(
            topic=self._settings.kafka_topic_market_events
        )
        await kafka_producer.start()
        self._kafka = kafka_producer

        try:
            while not self._stop_event.is_set():
                t0 = time.monotonic()
                self._stats.cycles_total += 1

                # Aplica backoff se necessário (após 429)
                if self._backoff > 0:
                    self._stats.backoff_until = (
                        datetime.utcnow().isoformat()
                    )
                    logger.info("producer.backoff", seconds=self._backoff)
                    await asyncio.sleep(self._backoff)
                    self._backoff = 0.0

                try:
                    published = await self._fetch_and_publish(tickers)
                    self._stats.cycles_ok        += 1
                    self._stats.events_published += published
                    self._stats.last_error        = ""
                    logger.info(
                        "producer.cycle.ok",
                        published=published,
                        tickers=len(tickers),
                    )
                except TransientError as exc:
                    # 429 ou timeout — aplica backoff exponencial
                    self._stats.cycles_error += 1
                    self._stats.last_error    = str(exc)
                    self._backoff = min(self._backoff * 2 + 1.0, _BACKOFF_CAP)
                    logger.warning("producer.cycle.transient", error=str(exc), backoff=self._backoff)
                except MarketDataUnavailableError as exc:
                    self._stats.cycles_error += 1
                    self._stats.last_error    = str(exc)
                    logger.warning("producer.cycle.error", error=str(exc))
                except Exception as exc:
                    self._stats.cycles_error += 1
                    self._stats.last_error    = str(exc)
                    logger.error("producer.cycle.unexpected", error=str(exc))

                elapsed = time.monotonic() - t0
                self._stats.last_cycle_at = datetime.utcnow().isoformat()
                self._stats.last_cycle_ms = round(elapsed * 1000, 1)

                # Dorme o intervalo restante (com jitter ±20%)
                base     = self._settings.producer_poll_interval_seconds
                jitter   = base * random.uniform(-0.2, 0.2)
                sleep_for = max(1.0, base + jitter - elapsed)

                logger.debug(
                    "producer.sleeping",
                    sleep_seconds=round(sleep_for, 1),
                    elapsed_ms=self._stats.last_cycle_ms,
                )
                try:
                    await asyncio.wait_for(
                        asyncio.shield(asyncio.ensure_future(self._stop_event.wait())),
                        timeout=sleep_for,
                    )
                    # Stop event setado durante o sleep
                    break
                except asyncio.TimeoutError:
                    pass  # Normal — continua o loop
        finally:
            await kafka_producer.stop()
            self._stats.running = False

    async def _fetch_and_publish(self, tickers: list[str]) -> int:
        """Busca preços na BRAPI e publica no Kafka. Retorna nº de eventos."""
        from finanalytics_ai.infrastructure.adapters.brapi_client import BrapiClient

        client = BrapiClient()
        events_published = 0

        # Processa em lotes de _BATCH_SIZE
        for i in range(0, len(tickers), _BATCH_SIZE):
            batch = tickers[i:i + _BATCH_SIZE]
            quotes = await self._fetch_batch(client, batch)

            for quote in quotes:
                event = self._quote_to_event(quote)
                if event:
                    await self._kafka.publish(event)
                    events_published += 1

        await client.close()
        return events_published

    async def _fetch_batch(
        self,
        client: Any,
        tickers: list[str],
    ) -> list[dict[str, Any]]:
        """
        Busca múltiplos tickers em um único request BRAPI.
        BRAPI aceita: /quote/PETR4,VALE3,ITUB4
        """
        ticker_str = ",".join(tickers)
        try:
            data = await client._request_with_retry(
                f"/quote/{ticker_str}?fundamental=false"
            )
            return data.get("results", [])
        except (MarketDataUnavailableError, TransientError):
            raise
        except Exception as exc:
            logger.warning("producer.batch.error", tickers=tickers, error=str(exc))
            return []

    def _quote_to_event(self, quote: dict[str, Any]) -> MarketEvent | None:
        """Converte resultado BRAPI em MarketEvent."""
        ticker = quote.get("symbol") or quote.get("stock")
        price  = quote.get("regularMarketPrice")

        if not ticker or price is None:
            return None

        payload: dict[str, Any] = {
            "price":          float(price),
            "change":         quote.get("regularMarketChange"),
            "change_pct":     quote.get("regularMarketChangePercent"),
            "volume":         quote.get("regularMarketVolume"),
            "previous_close": quote.get("regularMarketPreviousClose"),
            "market_time":    quote.get("regularMarketTime"),
            "currency":       quote.get("currency", "BRL"),
            "source":         "brapi",
        }

        return MarketEvent(
            event_type = EventType.PRICE_UPDATE,
            ticker     = str(ticker).upper(),
            payload    = {k: v for k, v in payload.items() if v is not None},
            source     = "brapi-producer",
        )


# ── Singleton global ──────────────────────────────────────────────────────────
_producer: BrapiKafkaProducer | None = None


def get_producer() -> BrapiKafkaProducer:
    global _producer
    if _producer is None:
        _producer = BrapiKafkaProducer()
    return _producer
